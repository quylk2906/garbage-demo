// import reactLogo from './assets/react.svg';
// import viteLogo from '/vite.svg';

import './App.scss';

import Home from './containers/Home';

function App() {
  return (
    <main className="main">
      <Home />
    </main>
  );
}

export default App;
